import React from 'react';
import ProductSlider from './ProductSlider';

const App = () => {
  return (
    <div>
    
      <ProductSlider />
    </div>
  );
};

export default App;
